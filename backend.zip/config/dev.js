module.exports = {
    mongoURI: 'mongodb://localhost:27017/marshal84us',
    jwtSecret: 'kdjkasjqr8239r8kfj939209102jwqfjnbfj1309ri3ifjkvknvjkevnknvi13eui3fi130i013i00239tfkeit049igkjkvjvw049t09tofjkwrjt034tigdfkjgkdfjg0rt9304fsdkfj04t904gigo',
    jwtExpire: '24h'
} 
