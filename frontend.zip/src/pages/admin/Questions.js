import React from 'react'

export const Questions = () => {
  return (
    <div>
      
    </div>
  )
}
