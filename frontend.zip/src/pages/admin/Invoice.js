import React from 'react'

export const Invoice = () => {
    return (
        <div>
            
        </div>
    )
}
