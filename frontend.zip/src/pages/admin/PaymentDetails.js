import React from 'react'

export const PaymentDetails = () => {
    return (
        <div>
            
        </div>
    )
}
