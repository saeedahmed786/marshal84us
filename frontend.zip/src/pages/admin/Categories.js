import React from 'react'

export const Categories = () => {
  return (
    <div>
      
    </div>
  )
}
